import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useTheme } from "@/components/ThemeProvider";
import {
  LayoutDashboard, Calendar, Target, BookOpen, Dumbbell,
  Users, ChefHat, Sun, Moon, Menu, X,
} from "lucide-react";
import { Button } from "@/components/ui/button";

const NAV = [
  { path: "/",         label: "Dashboard",        icon: LayoutDashboard },
  { path: "/calendar", label: "Calendar",          icon: Calendar        },
  { path: "/goals",    label: "Goals, Projects & Tasks",  icon: Target          },
  { path: "/reading",  label: "Reading",           icon: BookOpen        },
  { path: "/workouts",       label: "Workouts",               icon: Dumbbell        },
  { path: "/relationships",  label: "Relationships",          icon: Users           },
  { path: "/recipes",        label: "Recipes",                icon: ChefHat         },
];

export default function AppShell({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { theme, toggle } = useTheme();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background flex">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-56 shrink-0 border-r bg-card h-screen sticky top-0">
        <div className="p-4 border-b">
          <div className="flex items-center gap-2.5">
            <svg aria-label="Planner" viewBox="0 0 32 32" width="26" height="26" fill="none">
              <rect x="2" y="6" width="28" height="24" rx="4" stroke="currentColor" strokeWidth="2" />
              <path d="M2 12h28" stroke="currentColor" strokeWidth="2" />
              <rect x="8" y="2" width="2" height="6" rx="1" fill="currentColor" />
              <rect x="22" y="2" width="2" height="6" rx="1" fill="currentColor" />
              <circle cx="10" cy="21" r="2" fill="hsl(var(--cat-goal))" />
              <circle cx="16" cy="21" r="2" fill="hsl(25 85% 52%)" />
              <circle cx="22" cy="21" r="2" fill="hsl(210 80% 48%)" />
            </svg>
            <span className="font-bold text-sm tracking-tight">Year Ahead</span>
          </div>
        </div>
        <nav className="flex-1 p-3 space-y-1">
          {NAV.map(({ path, label, icon: Icon }) => (
            <Link key={path} href={path}>
              <a className={`sidebar-item ${location === path ? "active" : ""}`}>
                <Icon size={17} />
                <span>{label}</span>
              </a>
            </Link>
          ))}
        </nav>
        <div className="p-3 border-t">
          <button onClick={toggle} className="sidebar-item w-full">
            {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
            <span>{theme === "dark" ? "Light mode" : "Dark mode"}</span>
          </button>
        </div>
      </aside>

      {/* Mobile header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 bg-card border-b h-14 flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <svg aria-label="Planner" viewBox="0 0 32 32" width="22" height="22" fill="none">
            <rect x="2" y="6" width="28" height="24" rx="4" stroke="currentColor" strokeWidth="2"/>
            <path d="M2 12h28" stroke="currentColor" strokeWidth="2"/>
          </svg>
          <span className="font-bold text-sm">Year Ahead</span>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={toggle} className="p-2 rounded-lg hover:bg-secondary transition-colors">
            {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
          </button>
          <button onClick={() => setMobileOpen(!mobileOpen)} className="p-2 rounded-lg hover:bg-secondary transition-colors">
            {mobileOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {/* Mobile nav drawer */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-40 bg-background/80 backdrop-blur-sm" onClick={() => setMobileOpen(false)}>
          <div className="absolute left-0 top-14 bottom-0 w-56 bg-card border-r p-3 space-y-1" onClick={(e) => e.stopPropagation()}>
            {NAV.map(({ path, label, icon: Icon }) => (
              <Link key={path} href={path}>
                <a className={`sidebar-item ${location === path ? "active" : ""}`} onClick={() => setMobileOpen(false)}>
                  <Icon size={17} /> <span>{label}</span>
                </a>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Page content */}
      <main className="flex-1 min-w-0 lg:pt-0 pt-14">
        {children}
      </main>
    </div>
  );
}
